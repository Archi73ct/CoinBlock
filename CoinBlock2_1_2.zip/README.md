# CoinBlock
Because of the rising popularity if javascript coin miners, i have created a simple FF extension that outright blocks scripts from Coin-Hive.


## To be added
The final goal is not to have hardcoded URLs to block, but instead analyze a *.js file to determine wether or not it mines coins.
